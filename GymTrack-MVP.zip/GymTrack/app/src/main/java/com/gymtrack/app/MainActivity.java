package com.gymtrack.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list; SharedPreferences prefs;
    int pad=24;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("gym",0); showHome();}
    TextView tv(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(20,20,20)); t.setPadding(pad,pad/2,pad,pad/2); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad,30,pad,20); root.setBackgroundColor(Color.WHITE);
        TextView h=tv(title,28); h.setTypeface(null,1); root.addView(h,new LinearLayout.LayoutParams(-1,-2));
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this); sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void showHome(){
        base("GymTrack");
        TextView sub=tv("Твой прогресс — в одном месте",16); list.addView(sub);
        Button add=btn("＋  Начать тренировку"); list.addView(add); add.setOnClickListener(v->newWorkout());
        TextView stats=tv("\nСТАТИСТИКА\nТренировок: "+prefs.getInt("workouts",0)+"\nЛучший жим: "+prefs.getString("bench","—")+" кг",17); list.addView(stats);
        TextView hist=tv("\nПОСЛЕДНЯЯ ТРЕНИРОВКА",18); hist.setTypeface(null,1); list.addView(hist);
        String last=prefs.getString("last","Пока нет записей. Добавь первую тренировку."); list.addView(tv(last,16));
        Button pro=btn("GymTrack Pro — скоро"); list.addView(pro); pro.setOnClickListener(v->Toast.makeText(this,"Pro: расширенная статистика, программы и без рекламы",Toast.LENGTH_LONG).show());
    }
    void newWorkout(){
        base("Новая тренировка");
        EditText name=new EditText(this); name.setHint("Название, например: Грудь + плечи"); list.addView(name);
        EditText exercise=new EditText(this); exercise.setHint("Упражнение, например: Жим лёжа"); list.addView(exercise);
        EditText weight=new EditText(this); weight.setHint("Вес, кг"); weight.setInputType(2|8192); list.addView(weight);
        EditText reps=new EditText(this); reps.setHint("Повторы"); reps.setInputType(2); list.addView(reps);
        Button save=btn("Сохранить подход"); list.addView(save);
        TextView sets=tv("Подходы:\n",16); list.addView(sets);
        save.setOnClickListener(v->{
            String e=exercise.getText().toString().trim(), w=weight.getText().toString().trim(), r=reps.getText().toString().trim();
            if(e.isEmpty()||w.isEmpty()||r.isEmpty()){Toast.makeText(this,"Заполни упражнение, вес и повторы",Toast.LENGTH_SHORT).show();return;}
            String old=sets.getText().toString(); sets.setText(old+e+" — "+w+" кг × "+r+"\n");
            if(e.toLowerCase().contains("жим")){prefs.edit().putString("bench",w).apply();}
            prefs.edit().putInt("workouts",prefs.getInt("workouts",0)+1).putString("last",e+" — "+w+" кг × "+r).apply();
            exercise.setText(""); weight.setText(""); reps.setText("");
        });
        Button done=btn("✓ Завершить тренировку"); list.addView(done); done.setOnClickListener(v->showHome());
    }
    @Override public void onBackPressed(){showHome();}
}
